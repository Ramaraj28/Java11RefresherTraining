package com.hlag.aircargosystem;

import com.hlag.aircargosystem.entity.Cargo;

public class App {
    public static void main(String[] args) {
        // Create Cargo and FragileCargo objects
        Cargo cargo1 = new Cargo("C001", "Books", 50);
        FragileCargo fragileCargo = new FragileCargo("C002", "Glassware", 30, "Handle with care.");

        // Display details and track each cargo
        cargo1.displayDetails();
        cargo1.trackCargo();

        fragileCargo.displayDetails();
        fragileCargo.trackCargo();

        // Demonstrate polymorphism: treating FragileCargo as Cargo type
        Cargo cargo2 = fragileCargo;
        cargo2.displayDetails(); // Calls overridden method

        // Calculate shipping cost for each cargo using the getter for weight
        double cost1 = cargo1.calculateShippingCost(cargo1.getWeight(), 100);
        double cost2 = fragileCargo.calculateShippingCost(fragileCargo.getWeight(), 200);

        System.out.println("Shipping Cost for Cargo1: " + cost1);
        System.out.println("Shipping Cost for FragileCargo: " + cost2);
    }}

	

	
