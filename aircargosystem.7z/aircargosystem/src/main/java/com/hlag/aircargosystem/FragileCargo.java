package com.hlag.aircargosystem;
import com.hlag.aircargosystem.entity.Cargo;

class FragileCargo extends Cargo {
	private String handlingInstructions;

	public FragileCargo(String cargoId, String description, int weight, String instructions) {
		super(cargoId, description, weight);
		this.handlingInstructions = instructions;
	}

	// Override displayDetails to include handling instructions
	@Override
	public void displayDetails() {
		System.out.println("Handling Instructions: " + handlingInstructions);
	}
}