package com.hlag.aircargosystem;

//Interface Trackable for tracking capability
public interface Trackable {
	void trackCargo();
}