package com.hlag.aircargosystem.entity;

import com.hlag.aircargosystem.CargoItem;
import com.hlag.aircargosystem.Trackable;

public class Cargo extends CargoItem implements Trackable {
//	private  String cargoId;
	private String description;
    private int weight;

	public Cargo(String cargoId, String description, int weight) {
		super(cargoId);
		this.description = description;
		this.weight = weight;
	}

	// Calculate shipping cost based on weight and distance
	@Override
	public double calculateShippingCost(double weight, double distance) {
		return weight * distance * 0.05;
	}

	// Display cargo details
	public void displayDetails() {
		System.out.println("Cargo ID: " + cargoId + ", Description: " + description + ", Weight: " + weight);
	}

	// Track cargo
	@Override
	public void trackCargo() {
		System.out.println("Tracking cargo ID: " + cargoId);
	}

	public String getCargoId() {
		return cargoId;
	}

	public void setCargoId(String cargoId) {
		this.cargoId = cargoId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}
	
}
