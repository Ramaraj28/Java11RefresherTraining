package com.hlag.java11feature;

import java.util.Arrays;
import java.util.List;

public class LambdaExample {
    public static void main(String[] args) {
        List<String> cargoList = Arrays.asList("Electronics", "Furniture", "Clothing");
        
        // Using lambda expression to print each item
        cargoList.forEach(item -> System.out.println(item));
    }
}

