package com.hlag.java11feature;

public class StringMethodsExample {
	public static void main(String[] args) {
		String str = "  Hello, World!  ";
		String multilineStr = "Line 1\nLine 2\nLine 3";

		System.out.println("Is string blank? " + str.isBlank());

		System.out.println("Lines in multiline string:");
		multilineStr.lines().forEach(System.out::println);

		System.out.println("Stripped string: '" + str.strip() + "'");
		System.out.println("Leading stripped: '" + str.stripLeading() + "'");

		System.out.println("Trailing stripped: '" + str.stripTrailing() + "'");

		String repeatStr = "Java ";
		System.out.println("Repeated string: " + repeatStr.repeat(3));
	}
}
