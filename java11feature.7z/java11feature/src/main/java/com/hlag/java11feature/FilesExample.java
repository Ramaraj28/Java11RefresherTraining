package com.hlag.java11feature;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

/*public class FilesExample {
	 public static void main(String[] args) {
	        Path filePath = Paths.get("example.txt");
	        
	        try {
	            var lines = Files.readString(filePath);
	            System.out.println("File Content: " + lines);
	        } catch (IOException e) {
	            System.out.println("Error reading file: " + e.getMessage());
	        }
	    }

}*/


class FilesExample {
    public static void main(String[] args) {
        Path filePath = Paths.get("C://Users//GOVINRA/Downloads/ram//example.txt");
        
        try {
            List<String> lines = Files.readAllLines(filePath);
            for (String line : lines) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}
