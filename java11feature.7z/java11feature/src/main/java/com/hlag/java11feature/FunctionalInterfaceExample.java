package com.hlag.java11feature;

public class FunctionalInterfaceExample {
    public static void main(String[] args) {
        CargoProcessor processor = cargo -> System.out.println("Processing cargo: " + cargo);
        processor.process("Electronics");
    }
}

@FunctionalInterface
interface CargoProcessor {
    void process(String cargo);

}
