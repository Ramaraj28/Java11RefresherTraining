package com.hlag.java11feature.designpattern;
//Step 4: Demonstrate the Factory Pattern in action
public class MainFactory {
public static void main(String[] args) {
 // Create different shipments using the factory
 Shipment airShipment = ShipmentFactory.createShipment("air");
 Shipment seaShipment = ShipmentFactory.createShipment("sea");
 Shipment landShipment = ShipmentFactory.createShipment("land");

 // Deliver the shipments
 airShipment.deliver();
 seaShipment.deliver();
 landShipment.deliver();
}
}