package com.hlag.java11feature;

import java.util.Arrays;
import java.util.List;

public class MethodReferenceExample {

    public static void main(String[] args) {
        List<String> cargoList = Arrays.asList("Electronics", "Furniture", "Clothing");
        
        // Using method reference to print items
        cargoList.forEach(System.out::println);
    }

}
