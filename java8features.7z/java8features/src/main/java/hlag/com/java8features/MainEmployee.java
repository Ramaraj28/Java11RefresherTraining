package hlag.com.java8features;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class MainEmployee {
	public static void main(String[] args) {
		EmployeeRepositoryImpl employeeRepositoryImpl = new EmployeeRepositoryImpl();
		List<Employee> employees = Arrays.asList(new Employee("Ram", 50000.0, "IT", 39),
				new Employee("Raj", 50000.0, "HR", 39),
				new Employee("vimal", 40000.0, "Finance", 37),
				new Employee("Raja", 30000.0, "Finance", 37));
	
		for (Employee employee : employees) {
			employeeRepositoryImpl.save(employee);
		} 
		Map<String, Double> employeee =	employeeRepositoryImpl.getEmployeeBySalary();
		System.out.println("Employee : " + employeee);
		
	}
	
}
