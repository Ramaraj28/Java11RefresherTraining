package hlag.com.java8features.collector;
import java.util.*;
import java.util.stream.Collectors;

public class SalesReportMain {
    public static void main(String[] args) {
      
        List<Transaction> transactions = Arrays.asList(
            new Transaction(1, new Product("Laptop", "Electronics", 1000), new Customer("North", "Young Adults"), 10, 50),
            new Transaction(2, new Product("Phone", "Electronics", 500), new Customer("South", "Seniors"), 5, 20),
            new Transaction(3, new Product("Tablet", "Electronics", 300), new Customer("North", "Young Adults"), 15, 30),
            new Transaction(4, new Product("TV", "Appliances", 700), new Customer("East", "Middle-Aged"), 7, 40)
        );

        // Custom Report: Sales by Region and Demographic
        Map<String, Map<String, Integer>> salesByRegionAndDemographic = transactions.stream()
            .collect(Collectors.groupingBy(
                t -> t.getCustomer().getRegion(),
                Collectors.groupingBy(
                    t -> t.getCustomer().getDemographic(),
                    Collectors.summingInt(Transaction::getQuantity)
                )
            ));

        // Display the Report
        salesByRegionAndDemographic.forEach((region, demographicMap) -> {
            System.out.println("Region: " + region);
            demographicMap.forEach((demographic, totalSales) -> 
                System.out.println("  Demographic: " + demographic + " | Total Sales: " + totalSales)
            );
        });
    }
}
