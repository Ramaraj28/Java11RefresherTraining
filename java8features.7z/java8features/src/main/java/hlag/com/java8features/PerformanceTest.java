package hlag.com.java8features;

import java.util.ArrayList; import java.util.Arrays; import java.util.List;
import java.util.stream.Collector; import java.util.stream.Collectors;

import java.util.*;
import java.util.stream.Collectors;

public class PerformanceTest {
    public static void main(String[] args) {
        List<String> words = Arrays.asList("apple", "banana", "cherry", "date", "elderberry", "fig", "grape");

        // Measuring forEach Loop
        long startForEach = System.nanoTime();
        List<String> resultForEach = new ArrayList<>();
        for (String word : words) {
            if (word.length() > 5) {
                resultForEach.add(word.toUpperCase());
            }
        }
        long endForEach = System.nanoTime();

        // Measuring Stream API
        long startStream = System.nanoTime();
        List<String> resultStream = words.stream()
                .filter(word -> word.length() > 5)
                .map(String::toUpperCase)
                .collect(Collectors.toList());
        long endStream = System.nanoTime();

        System.out.println("For-each time: " + (endForEach - startForEach) + " ns");
        System.out.println("Stream time: " + (endStream - startStream) + " ns");
        
        System.out.println("For-each time: " + (endForEach - startForEach) / 1_000_000.0 + " ms");
        System.out.println("Stream time: " + (endStream - startStream) / 1_000_000.0 + " ms");
        
        System.out.println("Difference: " + ((endStream - startStream) - (endForEach - startForEach)) / 1_000_000.0 + " ms");
    }
}