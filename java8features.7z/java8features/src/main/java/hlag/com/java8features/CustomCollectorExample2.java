package hlag.com.java8features;

public class CustomCollectorExample2 {

}
