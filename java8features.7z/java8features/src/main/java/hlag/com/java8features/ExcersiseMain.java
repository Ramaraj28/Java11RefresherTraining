package hlag.com.java8features;

public class ExcersiseMain {

    public static void main(String[] args) {
        var number = 10; 
        var name = "Air Cargo"; 

        System.out.println("Number: " + number);
        System.out.println("Name: " + name);
    }}
