package hlag.com.java8features.thread;

import java.util.stream.IntStream;

public class ThreadDemo {
public static void main(String[] args) {
	Runnable runnable=()->{
		IntStream.range(1, 10).forEach(System.out::println);
	};
	Thread thred=new Thread(runnable);
	thred.start();
	Thread.getAllStackTraces().forEach((k,v)->{
		System.out.println(k);
	});
}
}
