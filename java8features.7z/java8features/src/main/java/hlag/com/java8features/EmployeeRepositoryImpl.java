package hlag.com.java8features;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class EmployeeRepositoryImpl {
	private List<Employee> employees = new ArrayList<Employee>();

	public void save(Employee employee) {
		employees.add(employee);
	}

	public Map<String, Double> getEmployeeBySalary() {
		// return employees.stream().filter(e -> e.getSalary() >
		// 50000.0).collect(Collectors.toList());

		Map<String, Double> filteremployee = employees.stream().filter(e -> e.getSalary() >= 50000)
				.collect(Collectors.toMap(Employee::getName, Employee::getSalary));
		return filteremployee;
		
       
		/*
		 * List<Double> totalsalary=employees.stream().filter(e -> e.getSalary() >
		 * 50000.0).map(Employee::getSalary).collect(Collectors.toList()); return
		 * employees;
		 */
		/*
		 * Map<String, Double> filteremployee = employees.stream().filter(e ->
		 * e.getSalary() > 50000) .collect(Collectors.toMap(Employee::getName,
		 * Employee::getSalary)); return employees;
		 */

		// Find the second-highest salary
		/*
		 * Optional<Double> secondHighestSalary = employees.stream()
		 * .map(Employee::getSalary) .filter(salary -> salary > 50000) .distinct() //
		 * Ensure no duplicates .sorted(Comparator.reverseOrder()) // Sort in descending
		 * order .skip(1) // Skip the highest salary .findFirst(); // Take the
		 * second-highest salary
		 */		
	}

}
