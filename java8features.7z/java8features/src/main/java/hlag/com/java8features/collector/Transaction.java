package hlag.com.java8features.collector;
public class Transaction {
    private int id;
    private Product product;
    private Customer customer;
    private int quantity;
    private double inventory;

    // Constructors
    public Transaction(int id, Product product, Customer customer, int quantity, double inventory) {
        this.id = id;
        this.product = product;
        this.customer = customer;
        this.quantity = quantity;
        this.inventory = inventory;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getInventory() {
        return inventory;
    }

    public void setInventory(double inventory) {
        this.inventory = inventory;
    }
}
