package hlag.com.java8features.collector;
public class Customer {
    private String region;
    private String demographic;

    // Constructors
    public Customer(String region, String demographic) {
        this.region = region;
        this.demographic = demographic;
    }

    // Getters and Setters
    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getDemographic() {
        return demographic;
    }

    public void setDemographic(String demographic) {
        this.demographic = demographic;
    }
}
