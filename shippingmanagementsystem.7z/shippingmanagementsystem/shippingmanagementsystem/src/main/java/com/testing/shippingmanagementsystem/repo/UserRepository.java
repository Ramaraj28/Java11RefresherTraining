package com.testing.shippingmanagementsystem.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.testing.shippingmanagementsystem.entity.User;


public class UserRepository {

	private List<User> users = new ArrayList<>();

	private static UserRepository userRepository;

	private UserRepository() {
	}

	public static UserRepository getInstance() {
		if (userRepository == null) {
			userRepository = new UserRepository();
		}
		return userRepository;
	}

	public User add(User user) {
		boolean result = users.add(user);
		if (result) {
			users.add(user);
		}
		return null;
	}

	public User getId(int id) {
		Optional<User> product = users.stream().filter(p -> p.getId() == id).findFirst();
		return product.orElse(null);
	}

	public void delete(int id) {
		users.removeIf(e -> e.getId() == id);
	}

	public void update(int id) {
		users.stream().filter(p -> p.getId() == id).forEach(p -> p.setUsername("ASDE"));
	}

	public List<User> getByUsers() {
		if (users.isEmpty()) {
			return new ArrayList<>();
		} else {
			return users;
		}
	}


}
