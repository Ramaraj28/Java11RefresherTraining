package com.hlag.logisticsystem.dto;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

public class Package {
private final String trackingId;
private double weight;
private String status;
private String destination;
private List<String> milestone;

/*
 * public Package(String trackingId, double weight, String destination,
 * List<String> milestone) { super(); this.trackingId = trackingId;
 * this.weight=weight; this.status="In Transit"; this.destination=destination;
 * this.milestone=milestone; }
 */
public Package() {
	this.trackingId="";
}
private static Package pack;
public static Package getInstance() {
	if(pack==null) {
		pack=new Package();
	}
	return pack;
}
public String getTrackingId() {
	return trackingId;
}

public void setWeight(double weight) {
    if (weight <= 0) {
        throw new IllegalArgumentException("Weight must be positive");
    }
    this.weight = weight;
}
public double getWeight() {
	return weight;
}

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}

public void setDestination(String destination) {
	this.destination = destination;
}
public String getDestination() {
	return destination;
}

public void setMilestone(List<String> milestone) {
	this.milestone = milestone;
}
public List<String> getMilestone() {
	return Collections.unmodifiableList(milestone);
}
public void markAsDeliverd(String status) {
	if(this.status.equals(status)) {
		throw new IllegalArgumentException("pkg is in tansit");
	}this.status="deliverd";
	this.milestone.add("deliverd on"+LocalDate.now());
}
}
