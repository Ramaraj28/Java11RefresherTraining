package com.hlag.logisticsystem;
import com.hlag.logisticsystem.dto.CargoItem;
import java.util.ArrayList;
import java.util.Scanner;

public class CargoItemApp {
    public static void main(String[] args) {
    	
        ArrayList<CargoItem> cargoList = new ArrayList<>();
        cargoList.add(new CargoItem(200, "10x10x10", "fragile"));
        cargoList.add(new CargoItem(700, "20x20x20", "standard"));
        cargoList.add(new CargoItem(1200, "30x30x30", "hazardous"));

     // Calculate total weights and logical operators  
        int totalWeight = 0;
        for (CargoItem item : cargoList) {
            totalWeight += item.getWeight();
        }
        System.out.println("Total Cargo Weight: " + totalWeight + " kg");
        
     // Classify and display shipping method based on weight
        for (CargoItem item : cargoList) {
            System.out.print(item.toString() + " - ");
            if (item.getWeight() <= 100) {
                System.out.println("Standard Shipping.");
            } else if (item.getWeight() <= 500) {
                System.out.println("Expedited Shipping.");
            } else {
                System.out.println("Heavy Cargo, requires special handling.");
            }
        }

        for (CargoItem item : cargoList) {
            System.out.println(item.toString() + " - Shipping Cost: $" + item.calculateShippingCost());
        }

        for (CargoItem item : cargoList) {
            switch (item.getType()) {
                case "fragile":
                    System.out.println(item.toString() + " - Handle with care.");
                    break;
                case "hazardous":
                    System.out.println(item.toString() + " - Follow safety protocols.");
                    break;
                default:
                    System.out.println(item.toString() + " - Regular handling.");
                    break;
            }
        }
//this is printing pourpse
        Scanner scanner = new Scanner(System.in);
        System.out.println("Add a new cargo item:");
        System.out.print("Enter weight (kg): ");
        int weight = scanner.nextInt();
        scanner.nextLine(); 
        System.out.print("Enter dimensions (LxWxH): ");
        String dimensions = scanner.nextLine();
        System.out.print("Enter type (e.g., fragile, hazardous, standard): ");
        String type = scanner.nextLine();

        CargoItem newItem = new CargoItem(weight, dimensions, type);
        cargoList.add(newItem);
        System.out.println("New cargo item added: " + newItem);
        scanner.close();
    }
    }

