package com.hlag.logisticsystem.repository;

import com.hlag.logisticsystem.BaseClass;
import com.hlag.logisticsystem.DrivedClass;

public class TestMain {
public static void main(String[] args) {
	BaseClass drived=new DrivedClass();
	drived.test();
}
}
