package com.hlag.logisticsystem;

public class BaseClass {
private int number1;
private int number2;

/*
 * protected BaseClass(int number1, int number2) { super(); this.number1 =
 * number1; this.number2 = number2; }
 */




  public static void test() {
	  System.out.println("test from base");
  }
 


}
