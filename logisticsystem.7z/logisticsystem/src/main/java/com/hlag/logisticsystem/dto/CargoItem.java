package com.hlag.logisticsystem.dto;

public class CargoItem {
    private int weight;
    
    private String dimensions;
    
    private String type;

    public CargoItem(int weight, String dimensions, String type) {
        this.weight = weight;
        this.dimensions = dimensions;
        this.type = type;
    }

    public int getWeight() {
        return weight;
    }

    public String getType() {
        return type;
    }

    public double calculateShippingCost() {
        double costPerKg = 2.5; 
        return weight * costPerKg;
    }

    @Override
    public String toString() {
        return "CargoItem [Weight: " + weight + " kg, Dimensions: " + dimensions + ", Type: " + type + "]";
    }
}