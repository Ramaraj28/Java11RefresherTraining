package com.hlag.logisticsystem;

public class IronMan implements Flyable {

	@Override
	public void fly() {
		System.out.println("Iron man fly");
	}
	public void display() {
		System.out.println("Iron man");	
	}

}
