package com.hlag.logisticsystem;

public class DrivedClass extends BaseClass{

	/*
	 * public DrivedClass() { super(10,20); }
	 */
public static void test() {
	System.out.println("test from drived");
}
}
