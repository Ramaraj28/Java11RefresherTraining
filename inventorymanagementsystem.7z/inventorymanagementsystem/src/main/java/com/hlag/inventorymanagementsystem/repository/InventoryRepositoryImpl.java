package com.hlag.inventorymanagementsystem.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.hlag.inventorymanagementsystem.entity.Product;

public class InventoryRepositoryImpl implements InventoryRepository {

	private List<Product> products = new ArrayList<Product>();
	private static InventoryRepositoryImpl inventoryRepositoryImpl;

	private InventoryRepositoryImpl() {

	}

	public static InventoryRepositoryImpl getInstance() {
		if (inventoryRepositoryImpl == null) {
			inventoryRepositoryImpl = new InventoryRepositoryImpl();
		}
		return inventoryRepositoryImpl;
	}

	@Override
	public Product addProduct(Product product) {
		boolean result = products.add(product);
		if (result) {
			return product;
		}
		return null;
	}

	@Override
	public Optional<Product> getProductById(String id) {
		UUID uuid = UUID.fromString(id);
		return products.stream().filter(e->e.getId().equals(uuid)).findFirst();
	}
	
	@Override
	public Optional<List<Product>> getProduct() {
		if (products.isEmpty()) {
			return Optional.empty();
		}else {
		return Optional.of(new ArrayList<Product>(products));
		}	
	}

	@Override
	public void deleteUser(String id) {
		UUID uuid = UUID.fromString(id);
		products.removeIf(product -> product.getId().equals(uuid));

	}

	@Override
	public Product updateProduct(String id, Product UpdateProduct) {
		UUID uuid = UUID.fromString(id);
		for (Product product : products) {
			if (product.getId().equals(uuid)) {
				product.setName(UpdateProduct.getName());
				return product;
			}
		}
		return null;
	}

}
