package com.hlag.inventorymanagementsystem;


import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import com.hlag.inventorymanagementsystem.entity.Product;
import com.hlag.inventorymanagementsystem.exception.InvalidNameException;
import com.hlag.inventorymanagementsystem.service.InventoryService;
import com.hlag.inventorymanagementsystem.service.InventoryServiceImpl;


public class App {
    private static InventoryService inventoryService = InventoryServiceImpl.getInstance();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws InvalidNameException {
       
    	String action = "ADD"; 

        switch (action) {
		    case "ADD":
		        // Add a new product
		        Product product = new Product("Laptop", "High-end gaming laptop", 150000.00, 10);
		        Product addedProduct = inventoryService.addProduct(product);
		        if (addedProduct != null) {
		            System.out.println("Product added successfully.");
		        }
		        break;

		    case "RETRIEVE_ALL":
		        // Retrieve and print all products
		        Optional<List<Product>> products = inventoryService.getProduct();
		        if (products.isPresent() && !products.get().isEmpty()) {
		            System.out.println("Product List: " + products.get());
		        } else {
		            System.out.println("No products found.");
		        }
		        break;

		    case "RETRIEVE_BY_ID":
		        // Retrieve product by ID
		        System.out.print("Enter Product ID to view: ");
		        String productId = scanner.nextLine();
		        Optional<Product> productById = inventoryService.getProductById(productId);
		        System.out.println(productById.isPresent() ? productById.get() : "Product not found.");
		        break;

		    case "UPDATE":
		        // Update an existing product
		        System.out.print("Enter Product ID to update: ");
		        String updateProductId = scanner.nextLine();
		        Product existingProduct = inventoryService.getProductById(updateProductId).orElse(null);
		        if (existingProduct != null) {
		            Product updatedProduct = new Product("Laptop Pro", "Upgraded gaming laptop", 180000.00, 8);
		            updateProduct(inventoryService, updateProductId, updatedProduct);
		        } else {
		            System.out.println("Product not found for update.");
		        }
		        break;

		    case "DELETE":
		        // Delete an existing product
		        System.out.print("Enter Product ID to delete: ");
		        String deleteProductId = scanner.nextLine();
		        deleteProduct(inventoryService, deleteProductId);
		        break;

		    default:
		        System.out.println("Invalid action.");
		        break;
		}
    }

    private static void updateProduct(InventoryService inventoryService, String id, Product updatedProduct) {
        Product result = inventoryService.updateProduct(id, updatedProduct);
        if (result != null) {
            System.out.println("Product updated successfully: " + result);
        } else {
            System.out.println("Product not found for update.");
        }
    }

    private static void deleteProduct(InventoryService inventoryService, String id) {
        inventoryService.deleteUser(id);
        System.out.println("Product deleted with ID: " + id);
    }
}
