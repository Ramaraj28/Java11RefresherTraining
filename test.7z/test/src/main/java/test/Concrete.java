package test;

import java.util.ArrayList;
import java.util.UUID;

public class Concrete extends AbstractTest {
	@Override
	public void method1() {
		System.out.println("Method 1 excuted");
		
	}

	@Override
	public void method8() {
		System.out.println("Method 8 excuted");
		
	}

	@Override
	public void method9() {
		System.out.println("Method 9 excuted");
		
	}

}
