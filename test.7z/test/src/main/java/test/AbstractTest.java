package test;

public abstract class AbstractTest implements I1, I2, I3 {


	@Override
	public void method5() {
		System.out.println("Method 5 excuted");

	}

	@Override
	public void method6() {
		System.out.println("Method 6 excuted");

	}

	@Override
	public void method7() {
		System.out.println("Method 7 excuted");

	}

	@Override
	public void method2() {
		System.out.println("Method 2 excuted");

	}

	@Override
	public void method3() {
		System.out.println("Method 3 excuted");

	}

	@Override
	public void method4() {
		System.out.println("Method 4 excuted");

	}

}
