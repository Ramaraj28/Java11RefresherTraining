package test;

public interface I2 {
	public void method5();
	public void method6();
	public void method7();
}
