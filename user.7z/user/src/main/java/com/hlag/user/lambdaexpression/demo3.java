package com.hlag.user.lambdaexpression;

public class demo3 {
	public static void main(String[] args) {
		Calculate cal = (int a) -> a % 7 == 0;
		boolean res=cal.check(2);
				System.out.println("result"+res);
				
	}
}

interface Calculate {
	boolean check(int a);
}