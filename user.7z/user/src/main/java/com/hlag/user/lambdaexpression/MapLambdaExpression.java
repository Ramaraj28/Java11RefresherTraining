package com.hlag.user.lambdaexpression;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

public class MapLambdaExpression {
	public static void main(String[] args) {
		demo();
		//Fuction
		Function<String, Integer> fuction = x -> x.length();
		System.out.println(fuction.apply("ram"));
		
	}

public static void demo() {
	Map<String, Integer> map=new HashMap<String, Integer>();
	map.put("A", 10);
	map.put("B", 20);
	map.put("C", 30);
	map.put("D", 40);
	map.put("F", 50);
	
	//For loop
	/*
	 * for (Map.Entry<String, Integer> entry : map.entrySet()) {
	 * System.out.println("Key : " + entry.getKey() + ", value  " + entry.getValue());
	 * }
	 */
	
	//foreach and lambda expercission
	  map.forEach((k,v)->{ System.out.println(k+"  "+v); });
}
}

interface Iop {
	public int add(int a, int b);
}