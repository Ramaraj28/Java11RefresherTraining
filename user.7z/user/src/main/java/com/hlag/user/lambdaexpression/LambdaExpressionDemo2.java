package com.hlag.user.lambdaexpression;

public class LambdaExpressionDemo2 {
    public static void main(String[] args) {
        Iops iops = (int a, int b) -> a + b;
        int res = iops.add(10, 20);
        System.out.println(res);
        demo((int a, int b) -> a + b + 10);
    }

    public static void demo(Iops iops) {
        System.out.println(iops.add(10, 2));
    }
}

interface Iops {
    public int add(int a, int b);
}
