package com.hlag.user.lambdaexpression;

public class NumberCheckDemo {
    public static void main(String[] args) {
        NumberCheck isEven = (int number) -> number % 2 == 0;

        int testNumber = 5;
        if (isEven.check(testNumber)) {
            System.out.println(testNumber + " is Even.");
        } else {
            System.out.println(testNumber + " is Odd.");
        }
    }
}

@FunctionalInterface
interface NumberCheck {
    boolean check(int number); 
}
