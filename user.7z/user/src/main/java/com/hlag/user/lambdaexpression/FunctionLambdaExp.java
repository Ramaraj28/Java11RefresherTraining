package com.hlag.user.lambdaexpression;

import java.util.function.Function;

public class FunctionLambdaExp {
	public static void main(String[] args) {

		// Fuction
		Function<String, Integer> fuction = x -> x.length();
		System.out.println(fuction.apply("ram"));

		// andThen
		Function<String, Integer> function = x -> x.length();
		Function<Integer, Integer> fun2 = x -> x * 2;
		int result = function.andThen(fun2).apply("ram");
System.out.println(result);
	}
}
