package com.hlag.user.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;


import com.hlag.user.entity.User;
import com.hlag.user.exception.InvalidNameException;

public class UserRepositoryImpl implements UserRepository {

	private List<User> users = new ArrayList<User>();
	private static UserRepositoryImpl userRepositoryImpl;

	private UserRepositoryImpl() {
	}

	public static UserRepositoryImpl getInstance() {
		if (userRepositoryImpl == null) {
			userRepositoryImpl = new UserRepositoryImpl();
		}
		return userRepositoryImpl;

	}

	@Override
	public User addUser(User user) {
		boolean result = users.add(user);
		if (result) {
			return user;
		}
		return null;
	}

	@Override
	public Optional<User> getUserById(String id) {
		UUID uuid = UUID.fromString(id);
		return users.stream().filter(e->e.getId().equals(uuid)).findFirst();
		
		/*//Solution:1
		 * for (User user : users) { if (user.getId().equals(uuid)) { return
		 * Optional.of(user); } } return Optional.empty();
		 */
		/*//Soultion:2
		 * AtomicReference<User> atomicReference=new AtomicReference<User>();
		 * Consumer<User> consumer=e->{ if((e.getId()).toString().equals(id)); {
		 * atomicReference.set(e); } }; users.forEach(consumer); User
		 * user3=atomicReference.get(); return Optional.ofNullable(user3);
		 */
	}

	@Override
	public Optional<List<User>> getUsers() {
		/*
		 * if (users.isEmpty()) return Optional.empty(); else { return
		 * Optional.of(users); }
		 */
		if (users.isEmpty()) {
			return Optional.empty();
		}else {
		return Optional.of(new ArrayList<User>(users));
		}	
	}
	
	@Override
	public void deleteUser(String id) {
	    UUID uuid = UUID.fromString(id);
	    users.removeIf(user -> user.getId().equals(uuid));
	}

	
	@Override
	public User updateUser(String id, User updatedUser) {
		UUID uuid = UUID.fromString(id);
		for (User user : users) {
			if (user.getId().equals(uuid)) {
				try {
					user.setFirstName(updatedUser.getFirstName());
					user.setEmailId(updatedUser.getEmailId());
				} catch (InvalidNameException e) {
					e.printStackTrace();
				}
				return user;
			}
		}
		return null; // If user with given ID does not exist
	}
}
