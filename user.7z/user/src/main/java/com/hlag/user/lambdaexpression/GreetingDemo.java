package com.hlag.user.lambdaexpression;
public class GreetingDemo {
    public static void main(String[] args) {
        Greeter greeter = (String name) ->  name;
        String message = greeter.greet("Hello, Alice!");
        System.out.println(message);
    }
}

@FunctionalInterface
interface Greeter {
    String greet(String name); 
}
