package com.hlag.user;

import java.util.List;
import java.util.Optional;

import com.hlag.user.entity.User;
import com.hlag.user.exception.InvalidNameException;
import com.hlag.user.service.UserService;
import com.hlag.user.service.UserServiceImpl;

public class App {

	public static void main(String[] args) {
		UserService userService = UserServiceImpl.getInstance();

		String action = "ADD"; // Change this value to test different actions

		try {
			switch (action) {
			case "ADD":
				// Add a new user
				User user = new User("Passw@rd1", "Ra", "raj", "7550046210", "ram@hlag.com");
				User addedUser = userService.addUser(user);
				if (addedUser != null) {
					System.out.println("User added successfully.");
				}
				break;

			case "RETRIEVE":
				// Retrieve and print all users
				Optional<List<User>> getUsers = userService.getUsers();
				if (getUsers.isPresent() && !getUsers.get().isEmpty()) {
					System.out.println(getUsers);
				} else {
					System.out.println("No users found.");
				}
				break;
			case "RETRIEVE_BY_ID":
				// Retrieve user by ID 
				Optional<List<User>> getUsersById = userService.getUsers();
				if (getUsersById.isPresent() && !getUsersById.get().isEmpty()) {
					String uuid = getUsersById.get().get(0).getId().toString();
					Optional<User> getuserId = userService.getUserById(uuid);
					System.out.println(getuserId);
				} else {
					System.out.println("No users found.");
				}
				break;

			case "UPDATE":
				// Update the first user
				Optional<List<User>> usersToUpdate = userService.getUsers();
				if (usersToUpdate.isPresent() && !usersToUpdate.get().isEmpty()) {
					User firstUser = usersToUpdate.get().get(0);
					User updatedUser = new User("NewPassw@rd1", "Up", "updatedLastName", "7550049999",
							"updatedEmail@hlag.com");
					updateUser(userService, firstUser.getId().toString(), updatedUser);
				} else {
					System.out.println("No users found for update.");
				}
				break;

			case "DELETE":
				// Delete the first user
				Optional<List<User>> usersToDelete = userService.getUsers();
				if (usersToDelete.isPresent() && !usersToDelete.get().isEmpty()) {
					User firstUser = usersToDelete.get().get(0);
					deleteUser(userService, firstUser.getId().toString());
				} else {
					System.out.println("No users found for deletion.");
				}
				break;

			default:
				System.out.println("Invalid action");
				break;
			}

		} catch (InvalidNameException e) {
			e.printStackTrace();
		}
	}

	private static void updateUser(UserService userService, String id, User updatedUser) {
		User result = userService.updateUser(id, updatedUser);
		if (result != null) {
			System.out.println("User updated successfully: " + result);
		} else {
			System.out.println("User not found for update.");
		}
	}

	private static void deleteUser(UserService userService, String id) {
		userService.deleteUser(id);
		System.out.println("User deleted with ID: " + id);
	}
}
