package com.hlag.user.lambdaexpression;

public class LambdaExpression {
	public static void main(String[] args) {
		
		/*
		 * I5 i5 = new I5Imple(); boolean result = i5.test(); i5.test2();
		 */

		/*
		 * I5 i6 = () -> true; System.out.println(i6.test()); i6.test2();
		 */
		
		//void method
		I5 i6 = () -> {
		System.out.println("hello from lombda");
		};
		i6.test();
		i6.test2();
	}
}

@FunctionalInterface
interface I5 {
	public void test();

	public default void test2() {
		System.out.println("hello test2");
	}
}

class I5Imple implements I5 {

	/*
	 * @Override public boolean test() { System.out.println("hello from test");
	 * return true; }
	 */
	@Override
	public void test() {
		System.out.println("hello from test");
	}
	
	@Override
	public void test2() {
		System.out.println("test2 is override");
	}
}
