package com.hlag.user.entity;

import java.util.UUID;
import com.hlag.user.exception.InvalidNameException;

public class User {

    private UUID id;
    private String userName;
    private String password;
    private String firstName;
    private String lastName;
    private String contactNumber;
    private String emailId;

    public User(String password, String firstName, String lastName, String contactNumber, String emailId) throws InvalidNameException {
        this.id = UUID.randomUUID();
        setUserName(firstName, lastName);
        setPassword(password);
        setFirstName(firstName);
        this.lastName = lastName;
        setContactNumber(contactNumber);
        setEmailId(emailId);
    }

    public UUID getId() {
        return id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String firstName, String lastName) {
        this.userName = firstName + " " + lastName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        if (validatePassword(password)) {
            this.password = password;
        } else {
            throw new IllegalArgumentException(
                "Password must be minimum length of 8 characters i.e., at least one digit, one lowercase letter, one uppercase letter, one special character and no whitespace"
            );
        }
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) throws InvalidNameException {
        if (firstName.length() == 2) {
            this.firstName = firstName;
        } else {
            throw new InvalidNameException("First name should be two letters");
        }
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) throws InvalidNameException {
        if (validateMobileNumber(contactNumber)) {
            this.contactNumber = contactNumber;
        } else {
            throw new InvalidNameException("Invalid mobile number. It must be exactly 10 digits.");
        }
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) throws InvalidNameException {
        if (validateEmail(emailId)) {
            this.emailId = emailId;
        } else {
            throw new InvalidNameException("Invalid email address.");
        }
    }

    private boolean validatePassword(String password) {
        String regex = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$";
        return password != null && password.matches(regex);
    }

    private boolean validateMobileNumber(String mobileNumber) {
        String regex = "^[0-9]{10}$";
        return mobileNumber != null && mobileNumber.matches(regex);
    }

    private boolean validateEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        return email != null && email.matches(emailRegex);
    }

    @Override
    public String toString() {
        return "User [id=" + id + ", userName=" + userName + ", password=" + password + ", firstName=" + firstName
                + ", lastName=" + lastName + ", contactNumber=" + contactNumber + ", emailId=" + emailId + "]";
    }
}
